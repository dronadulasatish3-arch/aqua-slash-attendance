// =======================================================
// AQUA SLASH — Live Google Backend Configuration
// Connected to "face sheet" + "face attendance / Registered_Faces"
// =======================================================

export const LIVE_GAS_URL =
  "https://script.google.com/macros/s/AKfycbw--R52zKu4alyXzS3OEXrpGmMOdIYwmi7M-VtftGYg6XlOsH_rlGrl7QVbio9DjlkAdA/exec";

export const REGISTRATION_URL = LIVE_GAS_URL;
export const ATTENDANCE_URL = LIVE_GAS_URL;

export const SHEET_ID = "1keNtJdMbyT7_kNYJq6Inbtm0HrZKR5wVN9nebugg4Uo";
export const DRIVE_FOLDER_ID = "1akmXAdAXuCrl_rSBhnzetRtEIJLdtqdr";

export const SHEET_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/edit`;
export const DRIVE_URL = `https://drive.google.com/drive/folders/${DRIVE_FOLDER_ID}`;

const CFG_KEY = "aqua_cfg_overrides_v3";

// Clean up any legacy v1 demo/override keys so stale data never interferes.
try {
  localStorage.removeItem("aqua_cfg_overrides");
  localStorage.removeItem("aqua_employees_v1");
  localStorage.removeItem("aqua_attendance_v1");
} catch {
  /* ignore storage errors */
}

export interface EndpointOverrides {
  registrationUrl?: string;
  attendanceUrl?: string;
}

export function getEndpoints(): { registration: string; attendance: string } {
  try {
    const raw = localStorage.getItem(CFG_KEY);
    if (raw) {
      const o = JSON.parse(raw) as EndpointOverrides;
      return {
        registration: (o.registrationUrl || REGISTRATION_URL).trim(),
        attendance: (o.attendanceUrl || ATTENDANCE_URL).trim(),
      };
    }
  } catch {
    /* ignore */
  }
  return { registration: REGISTRATION_URL, attendance: ATTENDANCE_URL };
}

export function saveEndpointOverrides(o: EndpointOverrides) {
  localStorage.setItem(CFG_KEY, JSON.stringify(o));
}

export function resetEndpointOverrides() {
  localStorage.removeItem(CFG_KEY);
}
