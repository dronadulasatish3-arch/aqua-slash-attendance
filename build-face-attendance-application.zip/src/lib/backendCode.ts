// =======================================================
// AQUA SLASH — UNIFIED GOOGLE APPS SCRIPT BACKEND (v4)
// Paste into Code.gs -> Deploy -> Manage deployments ->
// Edit (pencil) -> Version: New version -> Deploy.
//
// Existing sheets are preserved (columns A-F of Attendance, Sheet1, Face_Data):
//   Sheet1             : full name | phone number | mail | Job Title | Face URL
//   Face_Data          : Full Name | Phone Number | Job Title | Face Descriptor
//   Attendance         : Date | Phone | Name | Job Title | Check In | Check Out  (+ GPS columns G..Q appended)
// New sheets (created automatically on first use):
//   Communities, Students, Student_Attendance, Staff_Assignments, Settings
// =======================================================

export const UNIFIED_CODE_GS = `
// =======================================================
// AQUA SLASH — UNIFIED BACKEND v4
// Staff + Students + Communities + GPS (record-only) + PIN access
// =======================================================
var DRIVE_FOLDER_ID = "1akmXAdAXuCrl_rSBhnzetRtEIJLdtqdr";
var SHEET_ID        = "1keNtJdMbyT7_kNYJq6Inbtm0HrZKR5wVN9nebugg4Uo";
var SUBFOLDER_NAME  = "Registered_Faces";
var VERSION = 4;

var ST_IN    = "Inside assigned location";
var ST_OUT   = "Outside assigned location";
var ST_NOGPS = "GPS unavailable";
var ST_NOCOM = "No community assigned";
var ST_NOLOC = "Community location not set";

var ATT_GPS_HEADERS = ["Community","In Latitude","In Longitude","In Accuracy (m)","In Distance (m)","In Location Status","Out Latitude","Out Longitude","Out Accuracy (m)","Out Distance (m)","Out Location Status"];
var SA_HEADERS = ["Date","Community","Student","Check In","Check Out","Student ID","Community ID","In Latitude","In Longitude","In Accuracy (m)","In Distance (m)","In Location Status","Out Latitude","Out Longitude","Out Accuracy (m)","Out Distance (m)","Out Location Status","Marked By"];

// ---------- ENTRY POINTS ----------

function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.action) {
    return jsonOut_(handleApi_(String(p.action), p), p);
  }
  var template = HtmlService.createTemplateFromFile("Index");
  template.initialMode = p.page || "login";
  return template.evaluate()
    .setTitle("Aqua Slash — Biometric Attendance")
    .addMetaTag("viewport", "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function doPost(e) {
  var body = {};
  try { body = JSON.parse((e && e.postData && e.postData.contents) || "{}"); } catch (err) { body = {}; }
  var p = (e && e.parameter) || {};
  var action = String(body.action || p.action || "");
  return jsonOut_(handleApi_(action, body), p);
}

function jsonOut_(obj, p) {
  var text = JSON.stringify(obj);
  var cb = p && p.callback ? String(p.callback) : "";
  if (cb) {
    return ContentService.createTextOutput(cb + "(" + text + ");")
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(text)
    .setMimeType(ContentService.MimeType.JSON);
}

function handleApi_(action, p) {
  try {
    if (action === "ping") return { success: true, service: "aqua-slash-unified", version: VERSION, time: new Date().toISOString() };
    if (action === "bootstrap")        return bootstrap_();
    if (action === "login")            return login_(p);
    if (action === "setupAdminPin")    return setupAdminPin_(p);
    if (action === "changePins")       return changePins_(p);
    if (action === "dashboard")        return getDashboardData_();
    if (action === "register")         return registerAquaSlashEmployee(p);
    if (action === "updateFace")       return updateFaceTemplate_(p);
    if (action === "getFaces")         return { success: true, version: VERSION, employees: getRegisteredFaceTemplates() };
    if (action === "attendanceStatus") return { success: true, record: getTodayRecord_(String(p.phone || "")) };
    if (action === "todayAttendance")  return { success: true, dateKey: todayKey_(), records: getTodayAttendanceList_() };
    if (action === "checkIn")          return markAttendance_(p, "in");
    if (action === "checkOut")         return markAttendance_(p, "out");
    if (action === "saveCommunity")    return saveCommunity_(p);
    if (action === "assignStaff")      return assignStaff_(p);
    if (action === "students")         return listStudents_(p);
    if (action === "saveStudent")      return saveStudent_(p);
    if (action === "studentToday")     return studentToday_(p);
    if (action === "studentCheckIn")   return studentMark_(p, "in");
    if (action === "studentCheckOut")  return studentMark_(p, "out");
    if (action === "report")           return report_(p);
    return { success: false, message: "Unknown action: " + action };
  } catch (err) {
    return { success: false, message: "Server error: " + err.message };
  }
}

// ---------- GENERIC HELPERS ----------

function ss_() { return SpreadsheetApp.openById(SHEET_ID); }

function tz_() {
  return ss_().getSpreadsheetTimeZone() || "Asia/Kolkata";
}

function todayKey_() {
  return Utilities.formatDate(new Date(), tz_(), "yyyy-MM-dd");
}

function nowTime_() {
  return Utilities.formatDate(new Date(), tz_(), "HH:mm:ss");
}

function normPhone_(p) {
  var d = String(p || "").replace(/[^\\d]/g, "").trim();
  return d.length > 10 ? d.slice(-10) : d;
}

function extractDriveId_(url) {
  var s = String(url || "");
  var m1 = s.match(/\\/d\\/([a-zA-Z0-9_-]{15,})/);
  if (m1) return m1[1];
  var m2 = s.match(/[?&]id=([a-zA-Z0-9_-]{15,})/);
  return m2 ? m2[1] : "";
}

function ensureSheet_(name, headers) {
  var ss = ss_();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(headers);
    sh.setFrozenRows(1);
  }
  return sh;
}

function isTrue_(v) { return v === true || String(v).toUpperCase() === "TRUE"; }
function numOrNull_(v) {
  if (v === "" || v === null || v === undefined) return null;
  var n = parseFloat(v);
  return isFinite(n) ? n : null;
}
function numOr_(v, d) {
  var n = parseFloat(v);
  return isFinite(n) && n > 0 ? n : d;
}
function newId_(prefix) {
  return prefix + "-" + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 1296).toString(36).toUpperCase();
}

function getOrCreatePhotoFolder() {
  var parentFolder = DriveApp.getFolderById(DRIVE_FOLDER_ID);
  var subFolders = parentFolder.getFoldersByName(SUBFOLDER_NAME);
  return subFolders.hasNext() ? subFolders.next() : parentFolder.createFolder(SUBFOLDER_NAME);
}

// ---------- PIN ACCESS (Settings sheet) ----------

function settingsSheet_() { return ensureSheet_("Settings", ["Key", "Value"]); }

function getSetting_(key) {
  var data = settingsSheet_().getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === key) return String(data[i][1] === undefined ? "" : data[i][1]).trim();
  }
  return "";
}

function setSetting_(key, val) {
  var sh = settingsSheet_();
  var data = sh.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === key) {
      var c = sh.getRange(i + 1, 2);
      c.setNumberFormat("@");
      c.setValue(String(val));
      return;
    }
  }
  var r = sh.getLastRow() + 1;
  sh.getRange(r, 1, 1, 2).setNumberFormat("@");
  sh.getRange(r, 1, 1, 2).setValues([[key, String(val)]]);
}

function roleOf_(pin) {
  pin = String(pin || "").trim();
  if (!pin) return "";
  var admin = getSetting_("adminPin");
  var coach = getSetting_("coachPin");
  if (admin && pin === admin) return "admin";
  if (coach && pin === coach) return "coach";
  return "";
}

function requireRole_(pin, need) {
  var r = roleOf_(pin);
  var ok = need === "admin" ? r === "admin" : (r === "admin" || r === "coach");
  if (ok) return null;
  return { success: false, authError: true, message: need === "admin" ? "Admin PIN required." : "Coach or Admin PIN required." };
}

function login_(p) {
  if (!getSetting_("adminPin")) {
    return { success: false, needSetup: true, message: "Admin PIN is not set yet. Create it first." };
  }
  var r = roleOf_(p.pin);
  if (!r) return { success: false, message: "Incorrect PIN." };
  return { success: true, role: r };
}

function setupAdminPin_(p) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    if (getSetting_("adminPin")) return { success: false, message: "Admin PIN is already set." };
    var pin = String(p.pin || "").trim();
    if (pin.length < 4) return { success: false, message: "PIN must be at least 4 characters." };
    setSetting_("adminPin", pin);
    return { success: true, role: "admin" };
  } finally { lock.releaseLock(); }
}

function changePins_(p) {
  var denied = requireRole_(p.pin, "admin");
  if (denied) return denied;
  var na = String(p.newAdminPin || "").trim();
  var nc = String(p.newCoachPin || "").trim();
  if (na && na.length < 4) return { success: false, message: "Admin PIN must be at least 4 characters." };
  if (nc && nc.length < 4) return { success: false, message: "Coach PIN must be at least 4 characters." };
  var finalAdmin = na || getSetting_("adminPin");
  if (nc && nc === finalAdmin) return { success: false, message: "Coach PIN must be different from the Admin PIN." };
  if (na) setSetting_("adminPin", na);
  if (nc) setSetting_("coachPin", nc);
  return { success: true, coachSet: !!getSetting_("coachPin") };
}

// ---------- COMMUNITIES ----------

function communitiesSheet_() {
  var existed = !!ss_().getSheetByName("Communities");
  var sh = ensureSheet_("Communities", ["ID","Name","Address","Latitude","Longitude","Radius (m)","Active","Created"]);
  if (!existed) {
    // Seed the first community. Coordinates are left blank on purpose: pin it on the map in the app.
    sh.appendRow(["COM-SOBHA", "Sobha Indraprastha", "Sobha Indraprastha, Rajajinagar, Bengaluru", "", "", 200, true, new Date().toISOString()]);
  }
  return sh;
}

function readCommunities_() {
  var data = communitiesSheet_().getDataRange().getValues();
  var list = [];
  for (var i = 1; i < data.length; i++) {
    if (!data[i][0]) continue;
    list.push({
      id: String(data[i][0]),
      name: String(data[i][1] || ""),
      address: String(data[i][2] || ""),
      lat: numOrNull_(data[i][3]),
      lng: numOrNull_(data[i][4]),
      radius: numOr_(data[i][5], 100),
      active: isTrue_(data[i][6]),
      rowNumber: i + 1
    });
  }
  return list;
}

function findCommunity_(id) {
  if (!id) return null;
  var list = readCommunities_();
  for (var i = 0; i < list.length; i++) if (list[i].id === String(id)) return list[i];
  return null;
}

function saveCommunity_(p) {
  var denied = requireRole_(p.pin, "admin");
  if (denied) return denied;
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var name = String(p.name || "").trim().replace(/\\s+/g, " ");
    if (name.length < 2) return { success: false, message: "Community name is required." };
    var lat = numOrNull_(p.lat), lng = numOrNull_(p.lng);
    if ((lat === null) !== (lng === null)) return { success: false, message: "Enter both latitude and longitude, or leave both empty." };
    if (lat !== null && (Math.abs(lat) > 90 || Math.abs(lng) > 180)) return { success: false, message: "Latitude/longitude out of range." };
    var radius = numOr_(p.radius, 100);
    if (radius < 10) return { success: false, message: "Radius must be at least 10 metres." };
    var active = !(p.active === false || String(p.active).toLowerCase() === "false");
    var list = readCommunities_();
    var id = String(p.id || "");
    var existing = null;
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) existing = list[i];
      if (list[i].id !== id && list[i].name.toLowerCase() === name.toLowerCase()) {
        return { success: false, message: "A community named '" + list[i].name + "' already exists." };
      }
    }
    var sh = communitiesSheet_();
    if (id && !existing) return { success: false, message: "Community not found." };
    var created = new Date().toISOString();
    var row = [existing ? existing.id : newId_("COM"), name, String(p.address || "").trim(), lat === null ? "" : lat, lng === null ? "" : lng, radius, active, created];
    if (existing) {
      row[7] = sh.getRange(existing.rowNumber, 8).getValue() || created;
      sh.getRange(existing.rowNumber, 1, 1, 8).setValues([row]);
    } else {
      sh.getRange(sh.getLastRow() + 1, 1, 1, 8).setValues([row]);
    }
    SpreadsheetApp.flush();
    return { success: true, community: { id: row[0], name: name, address: row[2], lat: lat, lng: lng, radius: radius, active: active } };
  } finally { lock.releaseLock(); }
}

function bootstrap_() {
  var comms = readCommunities_();
  var out = [];
  for (var i = 0; i < comms.length; i++) {
    out.push({ id: comms[i].id, name: comms[i].name, address: comms[i].address, lat: comms[i].lat, lng: comms[i].lng, radius: comms[i].radius, active: comms[i].active });
  }
  return { success: true, version: VERSION, adminSet: !!getSetting_("adminPin"), coachSet: !!getSetting_("coachPin"), communities: out, assignments: readAssignments_() };
}

// ---------- STAFF ASSIGNMENTS ----------

function readAssignments_() {
  var data = ensureSheet_("Staff_Assignments", ["Phone", "Community ID"]).getDataRange().getValues();
  var map = {};
  for (var i = 1; i < data.length; i++) {
    var k = normPhone_(data[i][0]);
    if (k && data[i][1]) map[k] = String(data[i][1]);
  }
  return map;
}

function assignStaff_(p) {
  var denied = requireRole_(p.pin, "admin");
  if (denied) return denied;
  var list = p.assignments || [];
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var sh = ensureSheet_("Staff_Assignments", ["Phone", "Community ID"]);
    var data = sh.getDataRange().getValues();
    var rowOf = {};
    for (var i = 1; i < data.length; i++) rowOf[normPhone_(data[i][0])] = i + 1;
    var comms = readCommunities_();
    var valid = {};
    for (var c = 0; c < comms.length; c++) valid[comms[c].id] = true;
    var saved = 0;
    for (var j = 0; j < list.length; j++) {
      var k = normPhone_(list[j].phone);
      if (!k) continue;
      var cid = String(list[j].communityId || "");
      if (cid && !valid[cid]) continue;
      if (rowOf[k]) {
        sh.getRange(rowOf[k], 2).setValue(cid);
      } else if (cid) {
        var r = sh.getLastRow() + 1;
        sh.getRange(r, 1).setNumberFormat("@");
        sh.getRange(r, 1, 1, 2).setValues([[k, cid]]);
        rowOf[k] = r;
      }
      saved++;
    }
    SpreadsheetApp.flush();
    return { success: true, saved: saved, assignments: readAssignments_() };
  } finally { lock.releaseLock(); }
}

// ---------- GPS (record-only — never blocks attendance) ----------

function distM_(lat1, lon1, lat2, lon2) {
  var R = 6371000, toRad = Math.PI / 180;
  var dLat = (lat2 - lat1) * toRad, dLon = (lon2 - lon1) * toRad;
  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(lat1 * toRad) * Math.cos(lat2 * toRad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function gpsEval_(p, comm) {
  var lat = parseFloat(p.lat), lng = parseFloat(p.lng), acc = parseFloat(p.accuracy);
  var out = { status: "", distance: null, community: comm ? comm.name : "", radius: comm ? comm.radius : null, lat: null, lng: null, accuracy: null, note: "" };
  var hasGps = isFinite(lat) && isFinite(lng) && String(p.gpsStatus || "ok") !== "unavailable" && Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
  if (!hasGps) {
    out.status = ST_NOGPS;
    out.note = String(p.gpsReason || "Location could not be captured.");
    return out;
  }
  out.lat = lat; out.lng = lng; out.accuracy = isFinite(acc) ? Math.round(acc) : null;
  if (!comm) { out.status = ST_NOCOM; return out; }
  if (comm.lat === null || comm.lng === null) { out.status = ST_NOLOC; return out; }
  out.distance = Math.round(distM_(lat, lng, comm.lat, comm.lng));
  out.status = out.distance <= comm.radius ? ST_IN : ST_OUT;
  return out;
}

function gpsCells_(g) {
  return [
    g.lat === null ? "" : g.lat,
    g.lng === null ? "" : g.lng,
    g.accuracy === null ? "" : g.accuracy,
    g.distance === null ? "" : g.distance,
    g.status
  ];
}

// ---------- DASHBOARD (DRIVE PHOTOS + SHEET1 + FACE_DATA + ATTENDANCE) ----------

function getDashboardData_() {
  var ss = ss_();
  var tz = ss.getSpreadsheetTimeZone() || "Asia/Kolkata";
  var folder = getOrCreatePhotoFolder();

  var files = folder.getFiles();
  var driveFiles = [];
  var fileById = {};
  var fileByPhone = {};
  while (files.hasNext()) {
    var f = files.next();
    if (f.isTrashed()) continue;
    var created = f.getDateCreated();
    var info = {
      id: f.getId(),
      name: f.getName(),
      url: f.getUrl(),
      createdDisplay: Utilities.formatDate(created, tz, "dd MMM yyyy, hh:mm a"),
      createdMs: created.getTime()
    };
    driveFiles.push(info);
    fileById[info.id] = info;
    var pm = f.getName().match(/_(\\d+)\\.[a-zA-Z0-9]+$/);
    if (pm && pm[1]) {
      var pKey = normPhone_(pm[1]);
      if (!fileByPhone[pKey] || info.createdMs > fileByPhone[pKey].createdMs) fileByPhone[pKey] = info;
    }
  }
  driveFiles.sort(function(a, b) { return b.createdMs - a.createdMs; });

  var descByPhone = {};
  var bioRowsByPhone = {};
  var bioSheet = ss.getSheetByName("Face_Data");
  if (bioSheet) {
    var bData = bioSheet.getDataRange().getValues();
    for (var b = 1; b < bData.length; b++) {
      var bp = normPhone_(bData[b][1]);
      if (!bp) continue;
      bioRowsByPhone[bp] = {
        fullName: String(bData[b][0] || "").trim(),
        phone: String(bData[b][1] || "").trim(),
        jobTitle: String(bData[b][2] || "").trim()
      };
      if (bData[b][3]) {
        try {
          var parsed = JSON.parse(String(bData[b][3]));
          if (parsed && parsed.length === 128) descByPhone[bp] = parsed;
        } catch (err) {}
      }
    }
  }

  var sheet1 = ss.getSheets()[0];
  var sData = sheet1.getDataRange().getValues();
  var employees = [];
  var seenPhones = {};

  for (var i = 1; i < sData.length; i++) {
    var fullName = String(sData[i][0] || "").trim();
    var rawPhone = String(sData[i][1] || "").trim();
    var pNorm = normPhone_(rawPhone);
    if (!pNorm) continue; // skip stray rows without a phone number
    seenPhones[pNorm] = true;

    var email = String(sData[i][2] || "").trim();
    var jobTitle = String(sData[i][3] || "").trim();
    var faceUrl = String(sData[i][4] || "").trim();
    var fId = extractDriveId_(faceUrl);
    var dFile = (fId && fileById[fId]) ? fileById[fId] : (fileByPhone[pNorm] || null);
    var desc = descByPhone[pNorm] || [];

    employees.push({
      fullName: fullName,
      phone: rawPhone || pNorm,
      email: email,
      jobTitle: jobTitle,
      faceUrl: faceUrl || (dFile ? dFile.url : ""),
      registeredDate: dFile ? dFile.createdDisplay : "",
      hasFaceDescriptor: desc.length === 128,
      descriptor: desc
    });
  }

  for (var k in bioRowsByPhone) {
    if (!seenPhones[k]) {
      var br = bioRowsByPhone[k];
      var df = fileByPhone[k] || null;
      var d2 = descByPhone[k] || [];
      employees.push({
        fullName: br.fullName, phone: br.phone, email: "", jobTitle: br.jobTitle,
        faceUrl: df ? df.url : "", registeredDate: df ? df.createdDisplay : "",
        hasFaceDescriptor: d2.length === 128, descriptor: d2
      });
    }
  }

  return {
    success: true,
    version: VERSION,
    dateKey: Utilities.formatDate(new Date(), tz, "yyyy-MM-dd"),
    todayDisplay: Utilities.formatDate(new Date(), tz, "dd MMM yyyy"),
    registeredCount: employees.length,
    drivePhotoCount: driveFiles.length,
    latestDriveDate: driveFiles.length > 0 ? driveFiles[0].createdDisplay : "",
    employees: employees,
    todayAttendance: getTodayAttendanceList_()
  };
}

// ---------- STAFF REGISTRATION ----------

function registerAquaSlashEmployee(payload) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var ss = ss_();
    var sheet = ss.getSheets()[0];

    var data = sheet.getDataRange().getValues();
    var cleanPhone = String(payload.phone || "").trim();
    var pNorm = normPhone_(cleanPhone);
    var cleanEmail = String(payload.email || "").trim().toLowerCase();
    var incomingDesc = payload.faceDescriptor || payload.descriptor || null;

    var existingSheetIdx = -1;
    for (var i = 1; i < data.length; i++) {
      var rowPhone = normPhone_(data[i][1]);
      var rowEmail = String(data[i][2] || "").trim().toLowerCase();
      if ((pNorm && rowPhone === pNorm) || (cleanEmail && rowEmail === cleanEmail)) {
        existingSheetIdx = i;
        break;
      }
    }

    var bioSheet = ss.getSheetByName("Face_Data");
    if (!bioSheet) {
      bioSheet = ss.insertSheet("Face_Data");
      bioSheet.appendRow(["Full Name", "Phone Number", "Job Title", "Face Descriptor"]);
    }

    if (existingSheetIdx >= 0) {
      var bData = bioSheet.getDataRange().getValues();
      for (var b = 1; b < bData.length; b++) {
        if (normPhone_(bData[b][1]) === pNorm) {
          if (!bData[b][3] && incomingDesc && incomingDesc.length === 128) {
            bioSheet.getRange(b + 1, 4).setValue(JSON.stringify(incomingDesc));
            SpreadsheetApp.flush();
            return {
              success: true,
              fullName: String(data[existingSheetIdx][0] || payload.fullName).trim(),
              faceUrl: String(data[existingSheetIdx][4] || ""),
              message: "Biometric face template activated for existing employee!"
            };
          }
          break;
        }
      }
      return { success: false, message: "Already registered! This phone number or email is already in the system." };
    }

    var safeName = String(payload.fullName || "Employee").trim().replace(/[^a-zA-Z0-9]/g, "_");
    var fileName = safeName + "_" + pNorm + ".jpg";
    var base64Content = String(payload.photoBase64).indexOf(",") >= 0
      ? String(payload.photoBase64).split(",")[1]
      : String(payload.photoBase64);
    var imageBlob = Utilities.newBlob(Utilities.base64Decode(base64Content), "image/jpeg", fileName);

    var folder = getOrCreatePhotoFolder();
    var file = folder.createFile(imageBlob);
    var faceUrl = file.getUrl();

    sheet.appendRow([
      String(payload.fullName || "").trim(),
      cleanPhone,
      cleanEmail,
      String(payload.jobTitle || "").trim(),
      faceUrl
    ]);

    bioSheet.appendRow([
      String(payload.fullName || "").trim(),
      cleanPhone,
      String(payload.jobTitle || "").trim(),
      incomingDesc ? JSON.stringify(incomingDesc) : ""
    ]);

    SpreadsheetApp.flush();
    return { success: true, fullName: String(payload.fullName || "").trim(), faceUrl: faceUrl };
  } catch (err) {
    return { success: false, message: "Error: " + err.message };
  } finally {
    lock.releaseLock();
  }
}

function updateFaceTemplate_(payload) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var pNorm = normPhone_(payload.phone);
    var desc = payload.faceDescriptor || payload.descriptor;
    if (!pNorm || !desc || desc.length !== 128) {
      return { success: false, message: "Valid phone and 128-point face descriptor required." };
    }
    var ss = ss_();
    var bioSheet = ss.getSheetByName("Face_Data");
    if (!bioSheet) {
      bioSheet = ss.insertSheet("Face_Data");
      bioSheet.appendRow(["Full Name", "Phone Number", "Job Title", "Face Descriptor"]);
    }
    var bData = bioSheet.getDataRange().getValues();
    for (var i = 1; i < bData.length; i++) {
      if (normPhone_(bData[i][1]) === pNorm) {
        bioSheet.getRange(i + 1, 4).setValue(JSON.stringify(desc));
        SpreadsheetApp.flush();
        return { success: true, message: "Face AI template saved in Face_Data!" };
      }
    }
    bioSheet.appendRow([
      String(payload.fullName || "").trim(),
      String(payload.phone || "").trim(),
      String(payload.jobTitle || "").trim(),
      JSON.stringify(desc)
    ]);
    SpreadsheetApp.flush();
    return { success: true, message: "Face AI template added to Face_Data!" };
  } finally {
    lock.releaseLock();
  }
}

function getRegisteredFaceTemplates() {
  var bioSheet = ss_().getSheetByName("Face_Data");
  if (!bioSheet) return [];
  var data = bioSheet.getDataRange().getValues();
  var templates = [];
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] && data[i][3]) {
      try {
        templates.push({
          fullName: String(data[i][0]),
          phone: String(data[i][1]),
          jobTitle: String(data[i][2] || ""),
          descriptor: JSON.parse(data[i][3])
        });
      } catch (err) {}
    }
  }
  return templates;
}

// ---------- STAFF ATTENDANCE (existing columns A-F kept; GPS in G..Q) ----------

function attendanceSheet_() {
  var ss = ss_();
  var sh = ss.getSheetByName("Attendance");
  if (!sh) {
    sh = ss.insertSheet("Attendance");
    sh.appendRow(["Date", "Phone Number", "Full Name", "Job Title", "Check In", "Check Out"]);
  }
  if (!sh.getRange(1, 7).getValue()) {
    sh.getRange(1, 7, 1, ATT_GPS_HEADERS.length).setValues([ATT_GPS_HEADERS]);
  }
  return sh;
}

function cellDateKey_(rawVal, dispVal, tz) {
  if (rawVal instanceof Date) return Utilities.formatDate(rawVal, tz, "yyyy-MM-dd");
  var s = String(dispVal || rawVal || "").trim();
  if (/^\\d{4}-\\d{2}-\\d{2}$/.test(s)) return s;
  var d = new Date(s);
  if (!isNaN(d.getTime())) return Utilities.formatDate(d, tz, "yyyy-MM-dd");
  return s;
}

function cellTimeStr_(rawVal, dispVal, tz) {
  if (rawVal === "" || rawVal === null || rawVal === undefined) return String(dispVal || "").trim();
  if (rawVal instanceof Date) return Utilities.formatDate(rawVal, tz, "HH:mm:ss");
  return String(dispVal || rawVal || "").trim();
}

function findEmployeeInSheet1_(phone) {
  var pNorm = normPhone_(phone);
  if (!pNorm) return null;
  var ss = ss_();
  var data = ss.getSheets()[0].getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (normPhone_(data[i][1]) === pNorm) {
      return { fullName: String(data[i][0] || "").trim(), phone: String(data[i][1] || "").trim(), jobTitle: String(data[i][3] || "").trim() };
    }
  }
  var bio = ss.getSheetByName("Face_Data");
  if (bio) {
    var bData = bio.getDataRange().getValues();
    for (var j = 1; j < bData.length; j++) {
      if (normPhone_(bData[j][1]) === pNorm) {
        return { fullName: String(bData[j][0] || "").trim(), phone: String(bData[j][1] || "").trim(), jobTitle: String(bData[j][2] || "").trim() };
      }
    }
  }
  return null;
}

function getTodayAttendanceList_() {
  var sh = attendanceSheet_();
  var tz = tz_();
  var key = todayKey_();
  var raw = sh.getDataRange().getValues();
  var disp = sh.getDataRange().getDisplayValues();
  var byPhone = {};
  var order = [];
  for (var i = 1; i < raw.length; i++) {
    var dKey = cellDateKey_(raw[i][0], disp[i][0], tz);
    if (dKey !== key) continue;
    var phone = String(disp[i][1] || raw[i][1] || "").trim();
    var pNorm = normPhone_(phone);
    if (!pNorm) continue;
    var fullName = String(disp[i][2] || raw[i][2] || "").trim();
    var jobTitle = String(disp[i][3] || raw[i][3] || "").trim();
    var cIn = cellTimeStr_(raw[i][4], disp[i][4], tz);
    var cOut = cellTimeStr_(raw[i][5], disp[i][5], tz);
    var isLegacyOut = /CHECK-OUT/i.test(jobTitle);

    if (!byPhone[pNorm]) {
      byPhone[pNorm] = {
        rowNumber: i + 1,
        dateKey: key,
        phone: phone,
        fullName: fullName,
        jobTitle: jobTitle.replace(/\\s*·?\\s*CHECK-OUT/ig, "").trim(),
        checkIn: isLegacyOut ? "" : cIn,
        checkOut: isLegacyOut ? cIn : cOut,
        community: String(disp[i][6] || ""),
        inStatus: String(disp[i][11] || ""),
        inDistance: numOrNull_(raw[i][10]),
        outStatus: String(disp[i][16] || ""),
        outDistance: numOrNull_(raw[i][15])
      };
      order.push(pNorm);
    } else {
      var cur = byPhone[pNorm];
      if (isLegacyOut) {
        if (!cur.checkOut && cIn) cur.checkOut = cIn;
      } else {
        cur.rowNumber = i + 1;
        if (!cur.checkIn && cIn) cur.checkIn = cIn;
        if (cOut) cur.checkOut = cOut;
      }
    }
  }
  var list = [];
  for (var k = 0; k < order.length; k++) list.push(byPhone[order[k]]);
  return list;
}

function getTodayRecord_(phone) {
  var pNorm = normPhone_(phone);
  if (!pNorm) return null;
  var list = getTodayAttendanceList_();
  for (var i = list.length - 1; i >= 0; i--) {
    if (normPhone_(list[i].phone) === pNorm) return list[i];
  }
  return null;
}

function markAttendance_(p, mode) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var rawPhone = String(p.phone || "").trim();
    var pNorm = normPhone_(rawPhone);
    if (!pNorm) return { success: false, message: "Phone number is required to mark attendance." };

    var empFromSheet = findEmployeeInSheet1_(pNorm);
    var fullName = String(p.fullName || (empFromSheet ? empFromSheet.fullName : "") || "").trim();
    var jobTitle = String(p.jobTitle || (empFromSheet ? empFromSheet.jobTitle : "") || "").trim();
    var phoneToSave = empFromSheet ? empFromSheet.phone : rawPhone;

    if (!empFromSheet && !fullName) {
      return { success: false, message: "Phone number " + rawPhone + " is not registered yet. Please register first." };
    }

    var sh = attendanceSheet_();
    var rec = getTodayRecord_(pNorm);
    var key = todayKey_();
    var t = nowTime_();
    var comm = findCommunity_(readAssignments_()[pNorm]);
    var g = gpsEval_(p, comm);

    if (mode === "in") {
      if (rec && rec.checkIn) {
        return { success: false, already: true, message: "Already checked in today at " + rec.checkIn + ".", record: rec, gps: null };
      }
      var nextRow = sh.getLastRow() + 1;
      sh.getRange(nextRow, 1, 1, 6).setNumberFormat("@");
      var row = [key, phoneToSave, fullName, jobTitle, t, "", comm ? comm.name : ""].concat(gpsCells_(g)).concat(["", "", "", "", ""]);
      sh.getRange(nextRow, 1, 1, 17).setValues([row]);
      SpreadsheetApp.flush();
      return { success: true, message: "Checked in at " + t + ".", record: getTodayRecord_(pNorm), gps: g };
    }

    if (!rec || !rec.checkIn) {
      return { success: false, message: "No check-in found for today. Please Check In first.", record: rec, gps: null };
    }
    if (rec.checkOut) {
      return { success: false, already: true, message: "Already checked out today at " + rec.checkOut + ".", record: rec, gps: null };
    }
    var outCell = sh.getRange(rec.rowNumber, 6);
    outCell.setNumberFormat("@");
    outCell.setValue(t);
    sh.getRange(rec.rowNumber, 13, 1, 5).setValues([gpsCells_(g)]);
    SpreadsheetApp.flush();
    return { success: true, message: "Checked out at " + t + ".", record: getTodayRecord_(pNorm), gps: g };
  } finally {
    lock.releaseLock();
  }
}

// ---------- STUDENTS ----------

function studentsSheet_() { return ensureSheet_("Students", ["ID","Student Name","Community ID","Active","Created"]); }

function readStudents_() {
  var data = studentsSheet_().getDataRange().getValues();
  var list = [];
  for (var i = 1; i < data.length; i++) {
    if (!data[i][0]) continue;
    list.push({ id: String(data[i][0]), name: String(data[i][1] || ""), communityId: String(data[i][2] || ""), active: isTrue_(data[i][3]), rowNumber: i + 1 });
  }
  return list;
}

function findStudent_(id) {
  var list = readStudents_();
  for (var i = 0; i < list.length; i++) if (list[i].id === String(id)) return list[i];
  return null;
}

function listStudents_(p) {
  var denied = requireRole_(p.pin, "coach");
  if (denied) return denied;
  var out = readStudents_();
  for (var i = 0; i < out.length; i++) delete out[i].rowNumber;
  return { success: true, students: out };
}

function saveStudent_(p) {
  var isEdit = !!p.id;
  var denied = requireRole_(p.pin, isEdit ? "admin" : "coach");
  if (denied) return denied;
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var name = String(p.name || "").trim().replace(/\\s+/g, " ");
    if (name.length < 2) return { success: false, message: "Student name is required." };
    var comm = findCommunity_(p.communityId);
    if (!comm) return { success: false, message: "Please select a community." };
    var active = isEdit ? !(p.active === false || String(p.active).toLowerCase() === "false") : true;
    if (!isEdit && !comm.active) return { success: false, message: "That community is deactivated." };

    var list = readStudents_();
    var existing = null;
    for (var i = 0; i < list.length; i++) {
      if (isEdit && list[i].id === String(p.id)) existing = list[i];
      if ((!isEdit || list[i].id !== String(p.id)) && list[i].communityId === comm.id && list[i].name.toLowerCase() === name.toLowerCase()) {
        return { success: false, message: name + " is already registered in " + comm.name + "." };
      }
    }
    var sh = studentsSheet_();
    if (isEdit) {
      if (!existing) return { success: false, message: "Student not found." };
      sh.getRange(existing.rowNumber, 2, 1, 3).setValues([[name, comm.id, active]]);
      SpreadsheetApp.flush();
      return { success: true, student: { id: existing.id, name: name, communityId: comm.id, active: active } };
    }
    var id = newId_("STU");
    sh.getRange(sh.getLastRow() + 1, 1, 1, 5).setValues([[id, name, comm.id, true, new Date().toISOString()]]);
    SpreadsheetApp.flush();
    return { success: true, student: { id: id, name: name, communityId: comm.id, active: true } };
  } finally { lock.releaseLock(); }
}

// ---------- STUDENT ATTENDANCE ----------

function studentAttSheet_() { return ensureSheet_("Student_Attendance", SA_HEADERS); }

function readStudentToday_() {
  var sh = studentAttSheet_();
  var tz = tz_();
  var key = todayKey_();
  var raw = sh.getDataRange().getValues();
  var disp = sh.getDataRange().getDisplayValues();
  var list = [];
  for (var i = 1; i < raw.length; i++) {
    if (cellDateKey_(raw[i][0], disp[i][0], tz) !== key) continue;
    list.push({
      rowNumber: i + 1,
      dateKey: key,
      community: String(disp[i][1] || ""),
      student: String(disp[i][2] || ""),
      checkIn: cellTimeStr_(raw[i][3], disp[i][3], tz),
      checkOut: cellTimeStr_(raw[i][4], disp[i][4], tz),
      studentId: String(disp[i][5] || ""),
      communityId: String(disp[i][6] || ""),
      inStatus: String(disp[i][11] || ""),
      inDistance: numOrNull_(raw[i][10]),
      outStatus: String(disp[i][16] || ""),
      outDistance: numOrNull_(raw[i][15])
    });
  }
  return list;
}

function studentToday_(p) {
  var denied = requireRole_(p.pin, "coach");
  if (denied) return denied;
  return { success: true, dateKey: todayKey_(), records: readStudentToday_() };
}

function findStudentRecord_(list, studentId) {
  for (var i = list.length - 1; i >= 0; i--) if (list[i].studentId === studentId) return list[i];
  return null;
}

function studentMark_(p, mode) {
  var denied = requireRole_(p.pin, "coach");
  if (denied) return denied;
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var sid = String(p.studentId || "");
    var st = findStudent_(sid);
    if (!st) return { success: false, message: "Student not found." };
    if (!st.active) return { success: false, message: st.name + " is inactive." };
    var comm = findCommunity_(st.communityId);
    if (!comm) return { success: false, message: "This student has no valid community." };
    if (!comm.active) return { success: false, message: comm.name + " is deactivated. Activate it in Manage Communities to record attendance." };

    var g = gpsEval_(p, comm);
    var sh = studentAttSheet_();
    var key = todayKey_();
    var t = nowTime_();
    var rec = findStudentRecord_(readStudentToday_(), sid);

    if (mode === "in") {
      if (rec && rec.checkIn) {
        return { success: false, already: true, message: st.name + " is already checked in today at " + rec.checkIn + ".", record: rec, gps: null };
      }
      var nr = sh.getLastRow() + 1;
      sh.getRange(nr, 1, 1, 7).setNumberFormat("@");
      var row = [key, comm.name, st.name, t, "", st.id, comm.id].concat(gpsCells_(g)).concat(["", "", "", "", ""]).concat([roleOf_(p.pin)]);
      sh.getRange(nr, 1, 1, 18).setValues([row]);
      SpreadsheetApp.flush();
      return { success: true, message: st.name + " checked in at " + t + ".", record: findStudentRecord_(readStudentToday_(), sid), gps: g };
    }

    if (!rec || !rec.checkIn) {
      return { success: false, message: "No check-in found today for " + st.name + ". Please Check In first.", record: rec, gps: null };
    }
    if (rec.checkOut) {
      return { success: false, already: true, message: st.name + " is already checked out today at " + rec.checkOut + ".", record: rec, gps: null };
    }
    var c = sh.getRange(rec.rowNumber, 5);
    c.setNumberFormat("@");
    c.setValue(t);
    sh.getRange(rec.rowNumber, 13, 1, 5).setValues([gpsCells_(g)]);
    SpreadsheetApp.flush();
    return { success: true, message: st.name + " checked out at " + t + ".", record: findStudentRecord_(readStudentToday_(), sid), gps: g };
  } finally { lock.releaseLock(); }
}

// ---------- REPORTS (admin) ----------

function report_(p) {
  var denied = requireRole_(p.pin, "admin");
  if (denied) return denied;
  var type = String(p.type || "student");
  var from = String(p.from || ""), to = String(p.to || "");
  var cid = String(p.communityId || "");
  var cname = "";
  if (cid) { var cm = findCommunity_(cid); cname = cm ? cm.name.toLowerCase() : "__none__"; }
  var tz = tz_();
  var sh = type === "staff" ? attendanceSheet_() : studentAttSheet_();
  var raw = sh.getDataRange().getValues();
  var disp = sh.getDataRange().getDisplayValues();
  var rows = [];
  for (var i = raw.length - 1; i >= 1; i--) {
    var dk = cellDateKey_(raw[i][0], disp[i][0], tz);
    if (from && dk < from) continue;
    if (to && dk > to) continue;
    var row;
    if (type === "staff") {
      if (/CHECK-OUT/i.test(String(disp[i][3] || ""))) continue;
      var comm = String(disp[i][6] || "");
      if (cid && comm.toLowerCase() !== cname) continue;
      row = { type: "staff", dateKey: dk, community: comm, name: String(disp[i][2] || ""), ref: String(disp[i][1] || "") };
    } else {
      if (cid && String(disp[i][6] || "") !== cid) continue;
      row = { type: "student", dateKey: dk, community: String(disp[i][1] || ""), name: String(disp[i][2] || ""), ref: String(disp[i][5] || "") };
    }
    row.checkIn = cellTimeStr_(raw[i][type === "staff" ? 4 : 3], disp[i][type === "staff" ? 4 : 3], tz);
    row.checkOut = cellTimeStr_(raw[i][type === "staff" ? 5 : 4], disp[i][type === "staff" ? 5 : 4], tz);
    row.inLat = numOrNull_(raw[i][7]); row.inLng = numOrNull_(raw[i][8]);
    row.inDistance = numOrNull_(raw[i][10]); row.inStatus = String(disp[i][11] || "");
    row.outLat = numOrNull_(raw[i][12]); row.outLng = numOrNull_(raw[i][13]);
    row.outDistance = numOrNull_(raw[i][15]); row.outStatus = String(disp[i][16] || "");
    rows.push(row);
    if (rows.length >= 3000) break;
  }
  return { success: true, type: type, count: rows.length, rows: rows };
}
`.trim();
